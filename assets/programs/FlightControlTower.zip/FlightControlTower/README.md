# Flight Control Tower

## JUXT - Technical Test

*Author: Haaris Iqbal*

*Date: December 2022*

---

This application is a maven project made in IntelliJ and written in Java. It contains a POM file, seven classes, two test suites, three interfaces, an enumerated class and a README.md file. The project has been developed and organised in an MVC design pattern.

Test Driven Development methodology was used for multiple components, with a total of 47 JUnit tests. Appropriate Javadoc has been added to every functional file, and all Java code conforms to Google Checkstyle.

### Overview

Thoughtful design decisions were made throughout the process of development. A lot of effort was put into both robustness of the backend, and UI neatness / helpfulness.

Program features all functionality required from specification (and more):
-	Events can be added and updated.
-	Events can be deleted.
-	Appropriate error handling for incorrect inputs, duplicate inputs, and invalid inputs.
-	Status table displays status in required format. 
-	Status table will always update to reflect additions, detail changes, deletions.
-	Status table can display a status for any time stamp in the past or future and will take updates into account.
-	Custom commands for help, guide, listing all logged events, quitting the program.


More details on this project can be found in documentation.


### User Guide

Running Project
The project is titled “FlightControlTower” The dependencies needed for this project are downloaded automatically. The main entry point of the application is the “App.java” class. Running the main method from this class will start the program.

Running Tests
All tests were written with JUnit 5 Jupiter – thus for each JUnit test suite, all tests can be run individually or at once using JUnit 5. Earlier versions of JUnit should also work.

Use of Program
All user interaction with the program occurs through the console. 
When running the program, it will conform to the functionality required in the specification sheet. However, there are some reserved commands that have been included, which can be typed at any stage of the program loop:

-	“help”: To display commands, and other possible inputs.
-	“events”: To display all events that have been logged.
-	“guide": A display a user guide on how inputs work for this program.
-	“quit": To quit the program.

Other than these commands, the program works as follows:

1. An event can be added or updated by entering in the following format:


    Fxxx xxx ORIGIN DESTINATION Event-Type Time-Stamp Fuel-Delta


To break this down:
-	'Fxxx' is the PlaneID and must be four characters long.
-	'xxx' is the Plane Model and must be three characters long.
-	'ORIGIN' is the origin city of the flight. It may not be the same as the destination city.
-	'DESTINATION' is the destination city of the flight. It may not be the same as the origin city.
-	'Event-Status' is the type of event that has taken place. There may only be three event types:
  * 'Re-Fuel' indicating that the plane is now awaiting takeoff.
  * 'Take-Off' indicating that the plane is now in-flight.
  * 'Land' indicating that the plane has landed.
-	'TimeStamp' is the time stamp of when the event has taken place.
  * Time stamps must be in the format of: yyyy-MM-ddThh:mm:ss
  * An example of a valid time stamp is: 2021-03-29T14:00:00
-	'Fuel-Delta' is the change in fuel that has occurred due to the event. It must be a number.

2. Next, an event can be removed by providing a valid Plane ID and time stamp. The format should be as follows:


      Fxxx yyyy-MM-ddThh:mm:ss


3. Finally, a status table can be viewed for any timestamp simply by entering in the following format:


      yyyy-MM-ddThh:mm:ss

All of these formats conform to the inputs described in the project specification.
