/**
 * JUXT Technical Test, December 2022.
 * View class, to handle user interaction generally.
 *
 * @author Haaris Iqbal
 */

package com.haaris.ui;

import com.haaris.dto.Event;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class FCTView {
  // Initialization variables for Dependency Injection.
  private UserIOInterface io;

  /**
   * Instantiates a new View.
   *
   * @param io the User IO to be injected.
   */
  public FCTView(UserIOInterface io) {
    this.io = io;
  }

  /**
   * Introduction to the program.
   */
  public void introduction() {
    io.outln("\n*** Welcome to the Flight Control Tower Program! [©JUXT] ***");
    io.outln("This version of the program does not retain information, so there are currently no flight events.");
    io.outln("\nPlease input flight events. Or type 'help' for other commands.");
  }

  /**
   * Gets input.
   *
   * @return the input with case sensitivity.
   */
  public String getInput() {
    return io.inputCaseSensitive(); // Return with case sensitivity.
  }

  /**
   * Confirming that an event has successfully been added / updated.
   *
   * @param event the event that has been logged.
   */
  public void log(String event) {
    io.outln("\n'" + event + "' has successfully been logged!\n");
  }

  /**
   * Confirming that an event has successfully been deleted.
   *
   * @param event the event that has been deleted.
   */
  public void delete(String event) {
    io.outln("\n'" + event + "' has successfully been deleted!\n");
  }

  /**
   * Listing all the events that have been logged.
   *
   * @param allEvents A Hashmap of all events, with events corresponding to each individual plane.
   */
  public void list(HashMap<String, ArrayList<Event>> allEvents) {
    // No events in "database".
    if (allEvents.size() == 0) {
      io.outln("\nThere are no events that have been logged.");
    }

    // Display events if present.
    for (String PlaneID : allEvents.keySet()) {
      io.outln("\nAll logged events for " + PlaneID + " include:");
      for (Event e : allEvents.get(PlaneID)) {
        io.outln("- " + e.getPlaneID() + " " + e.getPlaneModel() + " " + e.getOrigin() + " " + e.getDestination() + " " + e.getTimeStamp().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + " " + e.getFuelDelta());
      }
    }
    io.outln("");
  }

  /**
   * Displaying a status table for a requested time stamp.
   *
   * @param statusTable the status table to be displayed.
   */
  public void table(HashSet<ArrayList<String>> statusTable) {
    // No events occurred at this time - thus no status table.
    if (statusTable.size() == 0) {
      io.outln("\nThere are no logged events that have occurred at this time.\n");
      return;
    }

    // Display events if present.
    io.outln("");
    for (ArrayList<String> flightStatus : statusTable) {
      io.outln(flightStatus.get(0) + " " + flightStatus.get(1) + " " + flightStatus.get(2));
    }
    io.outln("");
  }

  /**
   * Offering help on what to type in the program.
   *
   * @param commands the commands available to the user.
   */
  public void help(HashMap<String, String> commands) {
    io.outln("\nIf you are stuck, try some of the following: ");
    for (String key : commands.keySet()) {
      io.outln("-> " + key + " : " + commands.get(key));
    }
    io.outln("");
  }

  /**
   * Offering help on how to use the program as intended (a user guide).
   */
  public void guide() {
    io.outln("\n*********************************************************************");

    io.outln("\nThe program works as follows: ");

    io.outln("\n1. An event can be added or updated by entering in the following format:");

    io.outln("\n      Fxxx xxx ORIGIN DESTINATION Event-Type Time-Stamp Fuel-Delta");

    io.outln("\nTo break this down:");
    io.outln("- 'Fxxx' is the PlaneID, and must be four characters long.");
    io.outln("- 'xxx' is the Plane Model, and must be three characters long.");
    io.outln("- 'ORIGIN' is the origin city of the flight. It may not be the same as the destination city.");
    io.outln("- 'DESTINATION' is the destination city of the flight. It may not be the same as the origin city.");
    io.outln("- 'Event-Status' is the type of event that has taken place. There may only be three event types:");
    io.outln("    - 'Re-Fuel' indicating that the plane is now awaiting takeoff.");
    io.outln("    - 'Take-Off' indicating that the plane is now in-flight.");
    io.outln("    - 'Land' indicating that the plane has landed.");
    io.outln("- 'TimeStamp' is the time stamp of when the event has taken place.");
    io.outln("    - Time stamps must be in the format of : yyyy-MM-ddThh:mm:ss");
    io.outln("    - An example of a valid time stamp is  : 2021-03-29T14:00:00");
    io.outln("- 'Fuel-Delta' is the change in fuel that has occurred due to the event. It must be a number.");

    io.outln("\n2. Next, an event can be removed by providing a valid Plane ID and time stamp. The format should be as follows:");

    io.outln("\n      Fxxx yyyy-MM-ddThh:mm:ss");

    io.outln("\n3. Finally, a status table can be viewed for any timestamp simply by entering in the following format:");

    io.outln("\n      yyyy-MM-ddThh:mm:ss");

    io.outln("\nThat concludes the guide. Hope this has helped!");

    io.outln("\n*********************************************************************");

    io.outln("\nPlease input flight events. Or type 'help' for other commands.");
  }

  /**
   * Displaying that an input is invalid.
   */
  public void invalid() {
    io.outln("\nInvalid input!");
  }

  /**
   * Shut Scanner process and close the program.
   */
  public void quit() {
    io.outln("\nShutting program now!\n");

    io.close();
  }
}
