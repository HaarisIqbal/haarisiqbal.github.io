/**
 * JUXT Technical Test, December 2022.
 * EventDAO class, to manipulate data.
 *
 * @author Haaris Iqbal
 */

package com.haaris.dao;

import com.haaris.dto.Event;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

public class EventDAO implements EventDAOInterface {
  // Key variable: HashMap acting as a pseudo database, maintaining log of events.
  HashMap<String, ArrayList<Event>> allEvents = new HashMap<String, ArrayList<Event>>();

  /**
   * Log event to pseudo database. If event exist, event details will be updated
   *
   * @param event the event to log.
   */
  @Override
  public void addEvent(Event event) {
    // Dealing with the events of an existing flight.
    if (allEvents.containsKey(event.getPlaneID())) {
      boolean newEvent = true;

      // 1. Obtain events of specific flight.
      ArrayList<Event> flightEvents = allEvents.get(event.getPlaneID());

      // 2. Check if event already exists (based on immutable time stamp).
      for (Event e : flightEvents) {
        // Duplicate events identified, update event details.
        if (e.getTimeStamp().equals(event.getTimeStamp())) {
          newEvent = false;

          e.setPlaneModel(event.getPlaneModel());
          e.setOrigin(event.getOrigin());
          e.setDestination(event.getDestination());
          e.setEventType(event.getEventType());
          e.setFuelDelta(event.getFuelDelta());

          break;
        }
      }

      // 3. Event for this flight is new, simply add to events list of specific flight.
      if (newEvent) {
        flightEvents.add(event);
      }

      // 4. Change pseudo database with updated events list of specific flight.
      allEvents.put(event.getPlaneID(), flightEvents);
    }
    // Dealing with the events of a brand-new flight.
    else {
      ArrayList<Event> newFlightEvents = new ArrayList<Event>();
      newFlightEvents.add(event);

      // Simply creating a new key-value pair in pseudo database.
      allEvents.put(event.getPlaneID(), newFlightEvents);
    }
  }

  /**
   * Remove event from pseudo database.
   *
   * @param idAndTime ArrayList containing immutable variables to identify event to remove.
   * @return boolean for whether deletion as occurred or not.
   */
  @Override
  public boolean deleteEvent(String[] idAndTime) {
    // 1. Check pseudo database to see if Plane ID exists.
    if (!allEvents.containsKey(idAndTime[0])) {
      return false;
    }

    // 2. Check specific flight events to see if time stamp exists.
    ArrayList<Event> flightEvents = allEvents.get(idAndTime[0]); // Obtain branch.

    // Iterate over specific flight events.
    boolean remove = false;
    int index = 0;

    for (int i = 0; i < flightEvents.size(); i++) {
      // When event to be deleted is identified (by comparing time stamps).
      if (flightEvents.get(i).getTimeStamp().isEqual(LocalDateTime.parse(idAndTime[1]))) {
        remove = true;
        index = i;
        break;
      }
    }

    // 3. Update specific flight events list, and pseudo database.
    if (remove) {
      flightEvents.remove(index);

      // 3.1. Key value pair should only exist in pseudo database if flight has more than 0 events.
      if (flightEvents.size() == 0) {
        allEvents.remove(idAndTime[0]);
      } else {
        allEvents.put(idAndTime[0], flightEvents);
      }

    } else {
      return false;
    }

    // Successful deletion.
    return true;
  }

  /**
   * Return a current version of the "database" of events.
   *
   * @return An up-to-date HashMap "database".
   */
  @Override
  public HashMap<String, ArrayList<Event>> getEvents() {
    return this.allEvents;
  }
}
