package com.haaris.dao;

import com.haaris.dto.Event;

import java.util.ArrayList;
import java.util.HashMap;

public interface EventDAOInterface {
  void addEvent(Event event);

  boolean deleteEvent(String[] idAndTime);

  HashMap<String, ArrayList<Event>> getEvents();
}
