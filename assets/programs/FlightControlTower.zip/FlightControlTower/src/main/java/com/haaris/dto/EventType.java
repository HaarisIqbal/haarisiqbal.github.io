/**
 * JUXT Technical Test, December 2022.
 * EventType Enum class, to represent event types (data transfer object).
 *
 * @author Haaris Iqbal
 */

package com.haaris.dto;

public enum EventType {
  REFUEL,
  TAKEOFF,
  LAND
}
