/**
 * JUXT Technical Test, December 2022.
 * Event class, to represent an event (data transfer object).
 *
 * @author Haaris Iqbal
 */

package com.haaris.dto;

import java.time.LocalDateTime;

public class Event {
  // Key attributes of an event.
  private String planeID;
  private int planeModel;
  private String origin;
  private String destination;
  private EventType eventType;
  private LocalDateTime timeStamp;
  private int fuelDelta;

  /**
   * Constructor method to instantiate a new Event.
   *
   * @param planeID         The ID of the plane.
   * @param planeModel      The model number of the plane.
   * @param origin          The origin city of the plane.
   * @param destination     The destination city of the plane.
   * @param eventType       The type of action taken place in the event.
   * @param timeStampString The time that the event occurred.
   * @param fuelDelta       The change in fuel since the previous action.
   */
  public Event(String planeID, int planeModel, String origin, String destination, EventType eventType, String timeStampString, int fuelDelta) {
    setPlaneID(planeID);
    setPlaneModel(planeModel);
    setOrigin(origin);
    setDestination(destination);
    setEventType(eventType);
    setTimeStamp(timeStampString);
    setFuelDelta(fuelDelta);
  }

  // Getter Methods.

  /**
   * Gets the ID of the plane.
   *
   * @return the plane ID.
   */
  public String getPlaneID() {
    return planeID;
  }

  /**
   * Gets the model number of the plane.
   *
   * @return the model number.
   */
  public int getPlaneModel() {
    return planeModel;
  }

  /**
   * Gets the origin city of the plane.
   *
   * @return the origin city.
   */
  public String getOrigin() {
    return origin;
  }

  /**
   * Gets the destination city of the plane.
   *
   * @return the destination city.
   */
  public String getDestination() {
    return destination;
  }

  /**
   * Gets the type of action taken place on the plane.
   *
   * @return the event type.
   */
  public EventType getEventType() {
    return eventType;
  }

  /**
   * Gets the time the event occurred.
   *
   * @return the time stamp.
   */
  public LocalDateTime getTimeStamp() {
    return timeStamp;
  }

  /**
   * Gets the change in fuel since the previous action.
   *
   * @return the fuel delta.
   */
  public int getFuelDelta() {
    return fuelDelta;
  }

  // Setter methods.

  /**
   * Sets the ID of the plane.
   *
   * @param planeID new Plane ID.
   * @throws IllegalArgumentException Throws exception if IDs do not start with 'F', or do not have a length of 4.
   */
  public void setPlaneID(String planeID) {
    if (planeID.length() != 4 || planeID.toUpperCase().charAt(0) != 'F') {
      throw new IllegalArgumentException();
    }

    this.planeID = planeID;
  }

  /**
   * Sets the model of the plane.
   *
   * @param planeModel new plane model.
   * @throws IllegalArgumentException Throws exception if plane model is not 3 digits.
   */
  public void setPlaneModel(int planeModel) {
    if (String.valueOf(planeModel).length() != 3) {
      throw new IllegalArgumentException();
    }

    this.planeModel = planeModel;
  }

  /**
   * Sets the origin country of the plane.
   *
   * @param origin new origin country.
   * @throws IllegalArgumentException Throws exception if origin city is the same as the destination city.
   */
  public void setOrigin(String origin) {
    // Origin city will always be in upper case.
    origin = origin.toUpperCase();

    // Origin city may not be the same as the destination city.
    if (origin.equals(this.destination)) {
      throw new IllegalArgumentException();
    }

    this.origin = origin;
  }

  /**
   * Sets the destination country of the plane.
   *
   * @param destination new destination country.
   * @throws IllegalArgumentException Throws exception if destination city is the same as the origin city.
   */
  public void setDestination(String destination) {
    // Destination city will always be in upper case.
    destination = destination.toUpperCase();

    // Destination city may not be the same as origin city.
    if (destination.equals(this.origin)) {
      throw new IllegalArgumentException();
    }

    this.destination = destination;
  }

  /**
   * Sets the type of event that occurred.
   *
   * @param eventType The event type.
   * @throws IllegalArgumentException Throws exception for illogical changes of events.
   */
  public void setEventType(EventType eventType) {
    // Guard clause: Type cannot be "Land" if type is currently "Re-Fuel".
    if (eventType == EventType.LAND && this.eventType == EventType.REFUEL) {
      throw new IllegalArgumentException();
    }

    // Guard clause: Type cannot be "Re-Fuel" if type is currently "Take-off".
    if (eventType == EventType.REFUEL && this.eventType == EventType.TAKEOFF) {
      throw new IllegalArgumentException();
    }

    this.eventType = eventType;
  }

  /**
   * Sets the time stamp of the event.
   *
   * @param timeStampString new time stamp.
   */
  public void setTimeStamp(String timeStampString) {
    this.timeStamp = LocalDateTime.parse(timeStampString);
  }

  /**
   * Sets the change in fuel.
   *
   * @param fuelDelta new fuel delta.
   */
  public void setFuelDelta(int fuelDelta) {
    this.fuelDelta = fuelDelta;
  }
}
