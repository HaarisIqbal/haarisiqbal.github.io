/**
 * JUXT Technical Test, December 2022.
 * Controller class, to act as the interface between the UI and Service Layer.
 *
 * @author Haaris Iqbal
 */

package com.haaris.controller;

import com.haaris.service.FCTServiceLayerInterface;
import com.haaris.ui.FCTView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class FCTController {
  // Initialization variables for Dependency Injection.
  private FCTServiceLayerInterface serviceLayer;
  private FCTView view;

  // Controller variables.
  private boolean programLoop = true;
  private String input;
  private HashMap<String, String> commands = new HashMap<String, String>();

  /**
   * Constructor method to instantiate a new Controller.
   *
   * @param serviceLayer The Service Layer to be injected.
   * @param view         The View to be injected.
   */
  public FCTController(FCTServiceLayerInterface serviceLayer, FCTView view) {
    this.serviceLayer = serviceLayer;
    this.view = view;
  }

  /**
   * Main structure of the program.
   */
  public void runProgram() {
    initializeCommands();

    // Initialization.
    view.introduction();

    // Main loop.
    while (programLoop) {
      input = view.getInput();
      inputCase(input);
    }
  }

  /**
   * Private method making decisions based on given input.
   *
   * @param input the input from the UI.
   */
  private void inputCase(String input) {
    switch (input.toLowerCase()) {
      case "quit":
        view.quit();
        programLoop = false; // Ending loop after output message.
        break;
      case "events":
        view.list(serviceLayer.getEvents());
        break;
      case "guide":
        view.guide();
        break;
      case "help":
        view.help(commands);
        break;
      default:
        fctRequest(input);
    }
  }
  /**
   * Private method to process (potential) flight control tower requests.
   *
   * @param input the input from the UI.
   */
  private void fctRequest(String input) {
    input = input.toUpperCase();
    String[] details = input.split(" ");
    boolean success = true;

    switch (details.length) {
      case 1:
        // Requesting a status table.
        HashSet<ArrayList<String>> result = serviceLayer.getStatus(input);

        // Displaying in view.
        if (result != null) {
          view.table(result);
        } else {
          success = false;
        }
        break;
      case 2:
        // Requesting a deletion of an event.
        success = serviceLayer.removeEvent(input);

        // Displaying in view.
        if (success) {
          view.delete(input);
        }
        break;
      case 7:
        // Requesting an add or update of an event.
        success = serviceLayer.logEvent(input);

        // Displaying in view.
        if (success) {
          view.log(input);
        }
        break;
      default:
        success = false;
    }

    // If request was not processed, input was invalid.
    if (!success) {
      view.invalid();
    }
  }

  /**
   * Private method to initialize a HashSet of commands.
   */
  private void initializeCommands() {
    commands.clear();

    commands.put("help", "To display commands, and other possible inputs.");
    commands.put("events", "To display all events that have been logged.");
    commands.put("guide", "A display a user guide on how inputs work for this program.");
    commands.put("quit", "To quit the program.");
  }
}
