/**
 * JUXT Technical Test, December 2022.
 * Service Layer class, to manipulate DAOs and complete business-specific logic.
 *
 * @author Haaris Iqbal
 */

package com.haaris.service;

import com.haaris.dao.EventDAOInterface;
import com.haaris.dto.Event;
import com.haaris.dto.EventType;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class FCTServiceLayer implements FCTServiceLayerInterface {
  // Initialization variables for Dependency Injection.
  private EventDAOInterface dao;

  /**
   * Constructor method to instantiate a new Service Layer.
   *
   * @param dao The Data Access Object to be injected, for use by the service layer.
   */
  public FCTServiceLayer(EventDAOInterface dao) {
    this.dao = dao;
  }

  /**
   * Log an event.
   *
   * @param eventString The event to be logged.
   * @return boolean for whether logging was successful or unsuccessful.
   */
  @Override
  public boolean logEvent(String eventString) {
    // Obtain the details of the event.
    String[] eventDetails = eventString.split(" ");

    // Return false if the event has too few or too many details.
    if (eventDetails.length != 7) {
      return false;
    }

    // Return false if any event details that have been provided are blank.
    for (String s : eventDetails) {
      if (s.equals("")) {
        return false;
      }
    }

    // Determine the event type taking place, and return false for an invalid type.
    EventType et;
    switch (eventDetails[4].toLowerCase()) {
      case "re-fuel":
        et = EventType.REFUEL;
        break;
      case "take-off":
        et = EventType.TAKEOFF;
        break;
      case "land":
        et = EventType.LAND;
        break;
      default:
        return false;
    }

    // Create the event. [Unimplemented Improvement: Could catch custom errors and respond to them in different ways.]
    Event event;
    try {
      event = new Event(eventDetails[0], Integer.parseInt(eventDetails[1]), eventDetails[2], eventDetails[3], et, eventDetails[5], Integer.parseInt(eventDetails[6]));
    } catch (Exception e) {
      return false;
    }

    // Add the event to the pseudo database.
    dao.addEvent(event);

    // Having successfully logged, return true;
    return true;
  }

  /**
   * Remove an event.
   *
   * @param idAndTimeString The event to be removed.
   * @return boolean for whether logging was successful or unsuccessful.
   */
  @Override
  public boolean removeEvent(String idAndTimeString) {
    // Break input into an array.
    String[] idAndTimeDetails = idAndTimeString.split(" ");

    // Return false if there are too few or too many arguments.
    if (idAndTimeDetails.length != 2) {
      return false;
    }

    // Retrieve a copy of events from DAO.
    HashMap<String, ArrayList<Event>> allEvents = dao.getEvents();

    // If PlaneID is not present, removal does not occur.
    if (!allEvents.containsKey(idAndTimeDetails[0].toUpperCase())) {
      return false;
    }

    // Checking to see if timestamp is valid.
    LocalDateTime timeStamp;
    try {
      timeStamp = LocalDateTime.parse(idAndTimeDetails[1]);
    } catch (DateTimeParseException e) {
      return false;
    }

    // Checking to see if timestamp is present.
    boolean missing = true;
    for (Event e : allEvents.get(idAndTimeDetails[0].toUpperCase())) {
      if (e.getTimeStamp().isEqual(timeStamp)) {
        missing = false;
        break;
      }
    }

    // If timestamp is not present, removal does not occur.
    if (missing) {
      return false;
    }

    dao.deleteEvent(idAndTimeDetails);

    // Having succeeded in removal, return as complete.
    return true;
  }

  /**
   * Produce a status table.
   *
   * @param timeStamp The timestamp from which a status table is required.
   * @return A HashSet of Lists, containing status details for each individual flight relevant to the required timestamp.
   */
  @Override
  public HashSet<ArrayList<String>> getStatus(String timeStamp) {
    // First, checking to see if timestamp is valid.
    try {
      LocalDateTime.parse(timeStamp);
    } catch (DateTimeParseException e) {
      return null;
    }

    HashSet<ArrayList<String>> statusTable = new HashSet<ArrayList<String>>();

    // 1. Retrieve a copy of events from DAO.
    HashMap<String, ArrayList<Event>> allEvents = dao.getEvents();

    // 2. Construct status for each individual flight.
    for (String PlaneID : allEvents.keySet()) {
      ArrayList<String> status = new ArrayList<String>();

      // 2.1. Retrieve events for the specific flight.
      ArrayList<Event> thisFlightEvents = allEvents.get(PlaneID);

      // *** Plane ID ***

      // 3. Add Plane ID, if exists.
      boolean skip = true;
      for (Event e : thisFlightEvents) {
        if (e.getTimeStamp().isBefore(LocalDateTime.parse(timeStamp).plusSeconds(1))) {
          skip = false;
          status.add(PlaneID);
          break;
        }
      }

      // 3.1. If Plane ID not present, skip this iteration.
      if (skip) {
        continue; // Move to next set of flight events.
      }

      // *** Flight Status ***

      // 4. Determine current status based on a final event.
      Event finalEvent = null;

      // 4.1. Choosing a random event to act as final event, as long as its time is within required range.
      for (Event e : thisFlightEvents) {
        if (e.getTimeStamp().isBefore(LocalDateTime.parse(timeStamp).plusSeconds(1))) {
          finalEvent = e;
          break; // Stop iterating once suitable random event picked.
        }
      }

      // 4.2. Verifying that final logged event is indeed the last event within range, and updating if not.
      for (Event e : thisFlightEvents) {
        if (e.getTimeStamp().isBefore(LocalDateTime.parse(timeStamp).plusSeconds(1)) && e.getTimeStamp().isAfter(finalEvent.getTimeStamp())) {
          finalEvent = e;
        }
      }

      // 4.3. Determining event status to add to status table, based on event type.
      switch (finalEvent.getEventType()) {
        case REFUEL:
          status.add("Awaiting-Takeoff");
          break;
        case TAKEOFF:
          status.add("In-Flight");
          break;
        case LAND:
          status.add("Landed");
      }

      // *** Last Known Fuel Level ***

      // 5. Calculate fuel based on flight deltas.
      int finalFuel = 0;

      for (Event event : thisFlightEvents) {
        if (event.getTimeStamp().isBefore(LocalDateTime.parse(timeStamp).plusSeconds(1))) {
          finalFuel += event.getFuelDelta();
        }
      }

      status.add(String.valueOf(finalFuel));

      // 6. Finally, add new status.
      statusTable.add(status);
    }

    // 7. Return status table.
    return statusTable;
  }

  /**
   * Get a current version of the "database" of events from DAO.
   *
   * @return An up-to-date HashMap "database".
   */
  @Override
  public HashMap<String, ArrayList<Event>> getEvents() {
    return dao.getEvents();
  }
}
