package com.haaris.service;

import com.haaris.dto.Event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public interface FCTServiceLayerInterface {
  boolean logEvent(String eventString);

  boolean removeEvent(String idAndTimeString);

  HashSet<ArrayList<String>> getStatus(String timeStamp);

  HashMap<String, ArrayList<Event>> getEvents();
}
