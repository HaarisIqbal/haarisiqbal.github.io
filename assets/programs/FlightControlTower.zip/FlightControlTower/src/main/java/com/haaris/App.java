/**
 * JUXT Technical Test, December 2022.
 * App class, to call "execute" method and start program.
 *
 * @author Haaris Iqbal
 */

package com.haaris;

import com.haaris.controller.FCTController;
import com.haaris.dao.EventDAO;
import com.haaris.dao.EventDAOInterface;
import com.haaris.service.FCTServiceLayer;
import com.haaris.service.FCTServiceLayerInterface;
import com.haaris.ui.FCTView;
import com.haaris.ui.UserIO;
import com.haaris.ui.UserIOInterface;

public class App {
  /**
   * The entry point of application.
   *
   * @param args the input arguments.
   */
  public static void main(String[] args) {
    execute();
  }

  /**
   * Private method to start the program.
   */
  private static void execute() {
    // Key Variables for Dependency Injection.
    EventDAOInterface eventDAO = new EventDAO();
    FCTServiceLayerInterface serviceLayer = new FCTServiceLayer(eventDAO);

    UserIOInterface io = new UserIO();
    FCTView view = new FCTView(io);

    // A new FCT controller.
    FCTController controller = new FCTController(serviceLayer, view);

    // Starting program.
    controller.runProgram();
  }
}
