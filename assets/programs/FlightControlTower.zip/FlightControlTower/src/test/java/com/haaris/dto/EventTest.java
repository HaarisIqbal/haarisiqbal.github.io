package com.haaris.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;

import static org.junit.jupiter.api.Assertions.*;

class EventTest {
  private Event event; // Event object used throughout tests.
  private LocalDateTime timeStamp; // Timestamp used in multiple tests.

  // Populating event with valid items before each test.
  @BeforeEach
  void beforeEach() {
    event = new Event("F123", 737, "dublin", "lONDon", EventType.REFUEL, "2022-12-18T10:00:00", 300);
  }

  // Test 1.
  // Testing return of Plane ID.
  @Test
  void testGetPlaneID() {
    assertEquals("F123", event.getPlaneID());
  }

  // Test 2.
  // Testing return of plane model.
  @Test
  void testGetPlaneModel() {
    assertEquals(737, event.getPlaneModel());
  }

  // Test 3.
  // Testing return of origin.
  @Test
  void testGetOrigin() {
    assertEquals("DUBLIN", event.getOrigin());
  }

  // Test 4.
  // Testing return of destination.
  @Test
  void testGetDestination() {
    assertEquals("LONDON", event.getDestination());
  }

  // Test 5.
  // Testing return of event type.
  @Test
  void testGetEventType() {
    assertEquals(EventType.REFUEL, event.getEventType());
  }

  // Test 6.
  // Testing return of time stamp.
  @Test
  void testGetTimeStamp() {
    timeStamp = LocalDateTime.parse("2022-12-18T10:00:00");

    assertEquals(timeStamp, event.getTimeStamp());
  }

  // Test 7.
  // Testing return of fuel delta.
  @Test
  void testGetFuelDelta() {
    assertEquals(300, event.getFuelDelta());
  }

  // Test 8.
  // Testing setting Plane ID.
  @Test
  void testSetPlaneID() {
    assertEquals("F123", event.getPlaneID());

    event.setPlaneID("F321");

    assertEquals("F321", event.getPlaneID());
  }

  // Test 9.
  // Testing setting Plane ID with invalid ID.
  @Test
  void testSetPlaneIDInvalid() {
    assertThrows(IllegalArgumentException.class, () -> event.setPlaneID("F3213"));

    assertThrows(IllegalArgumentException.class, () -> event.setPlaneID("F32"));

    assertThrows(IllegalArgumentException.class, () -> event.setPlaneID("3213"));

    assertEquals("F123", event.getPlaneID()); // Plane ID has not changed.

    event.setPlaneID("F321");

    assertEquals("F321", event.getPlaneID()); // Plane ID has changed.
  }

  // Test 10.
  // Testing setting Plane Model.
  @Test
  void testSetPlaneModel() {
    assertEquals(737, event.getPlaneModel());

    event.setPlaneModel(700);

    assertEquals(700, event.getPlaneModel());
  }

  // Test 11.
  // Testing setting Plane Model with invalid model input.
  @Test
  void testSetPlaneModelInvalid() {
    assertThrows(IllegalArgumentException.class, () -> event.setPlaneModel(10000));

    assertThrows(IllegalArgumentException.class, () -> event.setPlaneModel(12));

    assertEquals(737, event.getPlaneModel()); // Plane model has not changed.

    event.setPlaneModel(425);

    assertEquals(425, event.getPlaneModel()); // Plane model has changed.
  }

  // Test 12.
  // Testing setting origin city.
  @Test
  void testSetOrigin() {
    assertEquals("DUBLIN", event.getOrigin());

    event.setOrigin("Glasgow");

    assertEquals("GLASGOW", event.getOrigin());
  }

  // Test 13.
  // Testing setting origin city with destination city.
  @Test
  void testSetOriginInvalid() {
    assertThrows(IllegalArgumentException.class, () -> event.setOrigin("London"));

    assertEquals("DUBLIN", event.getOrigin()); // Origin city has not changed.

    event.setOrigin("ParIS");

    assertEquals("PARIS", event.getOrigin()); // Origin city has changed.
  }

  // Test 14.
  // Testing setting destination city.
  @Test
  void testSetDestination() {
    assertEquals("LONDON", event.getDestination());

    event.setDestination("Frankfurt");

    assertEquals("FRANKFURT", event.getDestination());
  }

  // Test 15.
  // Testing setting destination city with origin city.
  @Test
  void testSetDestinationInvalid() {
    assertThrows(IllegalArgumentException.class, () -> event.setDestination("Dublin"));

    assertEquals("LONDON", event.getDestination()); // Destination city has not changed.

    event.setDestination("Athens");

    assertEquals("ATHENS", event.getDestination()); // Destination city has changed.
  }

  // Test 16.
  // Testing setting event type.
  @Test
  void testSetEventType() {
    assertEquals(EventType.REFUEL, event.getEventType());

    event.setEventType(EventType.TAKEOFF);

    assertEquals(EventType.TAKEOFF, event.getEventType());
  }

  // Test 17.
  // Testing setting event type with inappropriate states.
  @Test
  void testSetEventTypeInvalid() {
    assertThrows(IllegalArgumentException.class, () -> event.setEventType(EventType.LAND));

    assertEquals(EventType.REFUEL, event.getEventType());

    event.setEventType(EventType.TAKEOFF);

    assertEquals(EventType.TAKEOFF, event.getEventType());

    assertThrows(IllegalArgumentException.class, () -> event.setEventType(EventType.REFUEL));
  }

  // Test 18
  // Testing setting time stamp of event.
  @Test
  void testSetTimeStamp() {
    event.setTimeStamp("2022-12-18T10:30:12");

    timeStamp = LocalDateTime.parse("2022-12-18T10:30:12");

    assertEquals(timeStamp, event.getTimeStamp());
  }

  // Test 19
  // Testing setting time stamp of event with invalid input.
  @Test
  void testSetTimeStampInvalid() {
    assertThrows(DateTimeParseException.class, () -> event.setTimeStamp("BlahBlahBlah"));
  }

  // Test 20
  // Testing setting fuel delta.
  @Test
  void testSetFuelDelta() {
    assertEquals(300, event.getFuelDelta());

    event.setFuelDelta(400);

    assertEquals(400, event.getFuelDelta());
  }
}