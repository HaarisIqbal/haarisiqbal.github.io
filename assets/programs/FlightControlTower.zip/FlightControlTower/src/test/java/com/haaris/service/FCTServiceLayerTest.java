package com.haaris.service;

import com.haaris.dao.EventDAO;

import com.haaris.dao.EventDAOInterface;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.*;

class FCTServiceLayerTest {
  // Service layer used for testing purposes.
  private EventDAOInterface testDAO = new EventDAO();
  private FCTServiceLayer testServiceLayer = new FCTServiceLayer(testDAO);

  // Internal variables for testing.
  private HashSet<ArrayList<String>> statusTable;
  private String invalidEvent;

  private String f123event1;
  private String f123event2;
  private String f123event3;
  private String f222event1;
  private String f324event1;
  private String f551event1;
  private String f551event2;
  private String f551event3;

  private String f222event1Amended;
  private String f551event3Amended;


  @BeforeEach
  void beforeEach() {
    f222event1 = "F222 747 DUBLIN LONDON Re-Fuel 2021-03-29T10:00:00 200";
    f551event1 = "F551 747 PARIS LONDON Re-Fuel 2021-03-29T10:00:00 345";
    f324event1 = "F324 313 LONDON NEWYORK Take-off 2021-03-29T12:00:00 0";
    f123event1 = "F123 747 LONDON CARIO Re-Fuel 2021-03-29T10:00:00 428";
    f123event2 = "F123 747 LONDON CARIO Take-Off 2021-03-29T12:00:00 0";
    f551event2 = "F551 747 PARIS LONDON Take-Off 2021-03-29T11:00:00 0";
    f551event3 = "F551 747 PARIS LONDON Land 2021-03-29T12:00:00 -120";
    f123event3 = "F123 747 LONDON CARIO Land 2021-03-29T14:00:00 -324";

    f222event1Amended = "F222 747 DUBLIN LONDON Take-Off 2021-03-29T10:00:00 0";
    f551event3Amended = "F551 747 PARIS LONDON Land 2021-03-29T12:00:00 -300";
  }

  // Test 1.
  // Testing that initial status table is empty (given that no events have occurred).
  @Test
  void testInitialStatus() {
    statusTable = testServiceLayer.getStatus("2021-03-29T15:00:00");

    assertEquals(0, statusTable.size());
  }

  // Test 2.
  // Testing that logging one event produces a change in status table.
  @Test
  void testSingleLogAndStatus() {
    // Logging one event.
    assertTrue(testServiceLayer.logEvent(f222event1));

    // Getting status with timestamp after event.
    statusTable = testServiceLayer.getStatus("2021-03-29T15:00:00");

    // Preparing expected data.
    ArrayList<String> expectedResult = new ArrayList<>();
    expectedResult.add("F222");
    expectedResult.add("Awaiting-Takeoff");
    expectedResult.add("200");

    // Verifying if expected outcome occurred.
    assertEquals(1, statusTable.size());
    assertTrue(statusTable.contains(expectedResult));
  }

  // Test 3.
  // Testing that logging multiple events for a single flight linearly will reflect correctly in status table.
  @Test
  void testSingleFlightEvents() {
    // Logging multiple events of a single flight linearly.
    testServiceLayer.logEvent(f551event1);
    testServiceLayer.logEvent(f551event2);
    testServiceLayer.logEvent(f551event3);

    // Getting status with timestamp after all events.
    statusTable = testServiceLayer.getStatus("2021-03-29T15:00:00");

    // Preparing expected data.
    ArrayList<String> expectedResult = new ArrayList<>();
    expectedResult.add("F551");
    expectedResult.add("Landed");
    expectedResult.add("225");

    // Verifying if expected outcome occurred.
    assertEquals(1, statusTable.size());
    assertTrue(statusTable.contains(expectedResult));
  }

  // Test 4.
  // Testing that logging multiple events for multiple flights linearly will reflect correctly in status table.
  @Test
  void testMultipleFlightEvents() {
    // Logging multiple events of multiple flights linearly.
    testServiceLayer.logEvent(f123event1);
    testServiceLayer.logEvent(f222event1);
    testServiceLayer.logEvent(f123event2);

    // Getting status with timestamp after all events.
    statusTable = testServiceLayer.getStatus("2021-03-29T15:00:00");

    // Preparing expected data.
    ArrayList<String> expectedResult1 = new ArrayList<>();
    expectedResult1.add("F222");
    expectedResult1.add("Awaiting-Takeoff");
    expectedResult1.add("200");

    ArrayList<String> expectedResult2 = new ArrayList<>();
    expectedResult2.add("F123");
    expectedResult2.add("In-Flight");
    expectedResult2.add("428");

    // Verifying if expected outcome occurred.
    assertEquals(2, statusTable.size());
    assertTrue(statusTable.contains(expectedResult1));
    assertTrue(statusTable.contains(expectedResult2));
  }

  // Test 5.
  // Testing that logging multiple events for multiple flights linearly will reflect correctly in status table (large dataset).
  @Test
  void testMultipleFlightEventsLarge() {
    // Logging multiple events of multiple flights linearly.
    testServiceLayer.logEvent(f222event1);
    testServiceLayer.logEvent(f551event1);
    testServiceLayer.logEvent(f324event1);
    testServiceLayer.logEvent(f123event1);
    testServiceLayer.logEvent(f123event2);
    testServiceLayer.logEvent(f551event2);
    testServiceLayer.logEvent(f551event3);
    testServiceLayer.logEvent(f123event3);

    // Getting status with timestamp after all events.
    statusTable = testServiceLayer.getStatus("2021-03-29T15:00:00");

    // Preparing expected data.
    ArrayList<String> expectedResult1 = new ArrayList<>();
    expectedResult1.add("F222");
    expectedResult1.add("Awaiting-Takeoff");
    expectedResult1.add("200");

    ArrayList<String> expectedResult2 = new ArrayList<>();
    expectedResult2.add("F123");
    expectedResult2.add("Landed");
    expectedResult2.add("104");

    ArrayList<String> expectedResult3 = new ArrayList<>();
    expectedResult3.add("F324");
    expectedResult3.add("In-Flight");
    expectedResult3.add("0");

    ArrayList<String> expectedResult4 = new ArrayList<>();
    expectedResult4.add("F551");
    expectedResult4.add("Landed");
    expectedResult4.add("225");

    // Verifying if expected outcome occurred.
    assertEquals(4, statusTable.size());
    assertTrue(statusTable.contains(expectedResult1));
    assertTrue(statusTable.contains(expectedResult2));
    assertTrue(statusTable.contains(expectedResult3));
    assertTrue(statusTable.contains(expectedResult4));
  }

  // Test 6.
  // Testing that logging multiple events for multiple flights linearly with duplicate logs
  // will reflect correctly in status table (large dataset).
  @Test
  void testMultipleFlightEventsDuplicate() {
    // Logging multiple events of multiple flights linearly with duplicates.
    testServiceLayer.logEvent(f123event1);
    testServiceLayer.logEvent(f123event1);
    testServiceLayer.logEvent(f123event1);
    testServiceLayer.logEvent(f222event1);
    testServiceLayer.logEvent(f222event1);
    testServiceLayer.logEvent(f222event1);
    testServiceLayer.logEvent(f123event2);
    testServiceLayer.logEvent(f123event3);
    testServiceLayer.logEvent(f123event3);

    // Getting status with timestamp after all events.
    statusTable = testServiceLayer.getStatus("2021-03-29T15:00:00");

    // Preparing expected data.
    ArrayList<String> expectedResult1 = new ArrayList<>();
    expectedResult1.add("F222");
    expectedResult1.add("Awaiting-Takeoff");
    expectedResult1.add("200");

    ArrayList<String> expectedResult2 = new ArrayList<>();
    expectedResult2.add("F123");
    expectedResult2.add("Landed");
    expectedResult2.add("104");

    // Verifying if expected outcome occurred.
    assertEquals(2, statusTable.size());
    assertTrue(statusTable.contains(expectedResult1));
    assertTrue(statusTable.contains(expectedResult2));
  }

  // Test 7.
  // Testing that updating a previous event will reflect correctly in status table.
  @Test
  void testUpdating() {
    // Logging multiple events of multiple flights linearly.
    testMultipleFlightEventsLarge();

    // Updating by adding a near duplicate event, with a change in flight delta.
    testServiceLayer.logEvent(f551event3Amended);

    // Updating by changing event type and flight delta.
    testServiceLayer.logEvent(f222event1Amended);

    // Getting status with timestamp after all updates and events.
    statusTable = testServiceLayer.getStatus("2021-03-29T15:00:00");

    // Preparing expected data.
    ArrayList<String> expectedResult1 = new ArrayList<>();
    expectedResult1.add("F222");
    expectedResult1.add("In-Flight");
    expectedResult1.add("0");

    ArrayList<String> expectedResult2 = new ArrayList<>();
    expectedResult2.add("F123");
    expectedResult2.add("Landed");
    expectedResult2.add("104");

    ArrayList<String> expectedResult3 = new ArrayList<>();
    expectedResult3.add("F324");
    expectedResult3.add("In-Flight");
    expectedResult3.add("0");

    ArrayList<String> expectedResult4 = new ArrayList<>();
    expectedResult4.add("F551");
    expectedResult4.add("Landed");
    expectedResult4.add("45");

    // Verifying if expected outcome occurred.
    assertEquals(4, statusTable.size());
    assertTrue(statusTable.contains(expectedResult1));
    assertTrue(statusTable.contains(expectedResult2));
    assertTrue(statusTable.contains(expectedResult3));
    assertTrue(statusTable.contains(expectedResult4));
  }

  // Test 8.
  // Testing that logging multiple events for a single flight non-linearly will reflect correctly in status table.
  @Test
  void testSingleFlightEventsNonLinear() {
    // Logging multiple events of a single flight non-linearly.
    testServiceLayer.logEvent(f551event3);
    testServiceLayer.logEvent(f551event2);
    testServiceLayer.logEvent(f551event1);

    // Getting status with timestamp after all events.
    statusTable = testServiceLayer.getStatus("2021-03-29T15:00:00");

    // Preparing expected data.
    ArrayList<String> expectedResult = new ArrayList<>();
    expectedResult.add("F551");
    expectedResult.add("Landed");
    expectedResult.add("225");

    // Verifying if expected outcome occurred.
    assertEquals(1, statusTable.size());
    assertTrue(statusTable.contains(expectedResult));
  }

  // Test 9.
  // Testing that logging multiple events for multiple flights non-linearly will reflect correctly in status table.
  @Test
  void testMultipleFlightEventsNonLinear() {
    // Logging multiple events of multiple flights non-linearly (mixed order).
    testServiceLayer.logEvent(f123event3);
    testServiceLayer.logEvent(f222event1);
    testServiceLayer.logEvent(f551event2);
    testServiceLayer.logEvent(f551event3);
    testServiceLayer.logEvent(f551event1);
    testServiceLayer.logEvent(f324event1);
    testServiceLayer.logEvent(f123event1);
    testServiceLayer.logEvent(f123event2);

    // Getting status with timestamp after all events.
    statusTable = testServiceLayer.getStatus("2021-03-29T15:00:00");

    // Preparing expected data.
    ArrayList<String> expectedResult1 = new ArrayList<>();
    expectedResult1.add("F222");
    expectedResult1.add("Awaiting-Takeoff");
    expectedResult1.add("200");

    ArrayList<String> expectedResult2 = new ArrayList<>();
    expectedResult2.add("F123");
    expectedResult2.add("Landed");
    expectedResult2.add("104");

    ArrayList<String> expectedResult3 = new ArrayList<>();
    expectedResult3.add("F324");
    expectedResult3.add("In-Flight");
    expectedResult3.add("0");

    ArrayList<String> expectedResult4 = new ArrayList<>();
    expectedResult4.add("F551");
    expectedResult4.add("Landed");
    expectedResult4.add("225");

    // Verifying if expected outcome occurred.
    assertEquals(4, statusTable.size());
    assertTrue(statusTable.contains(expectedResult1));
    assertTrue(statusTable.contains(expectedResult2));
    assertTrue(statusTable.contains(expectedResult3));
    assertTrue(statusTable.contains(expectedResult4));
  }

  // Test 10.
  // Testing removing a single event will reflect correctly in status table.
  @Test
  void testRemoveSingleEvent() {
    // Logging multiple events of multiple flights.
    testMultipleFlightEventsLarge();

    // Removing a single event.
    assertTrue(testServiceLayer.removeEvent("F551 2021-03-29T12:00:00"));

    // Getting status with timestamp after all events.
    statusTable = testServiceLayer.getStatus("2021-03-29T15:00:00");

    // Preparing expected data.
    ArrayList<String> expectedResult1 = new ArrayList<>();
    expectedResult1.add("F222");
    expectedResult1.add("Awaiting-Takeoff");
    expectedResult1.add("200");

    ArrayList<String> expectedResult2 = new ArrayList<>();
    expectedResult2.add("F123");
    expectedResult2.add("Landed");
    expectedResult2.add("104");

    ArrayList<String> expectedResult3 = new ArrayList<>();
    expectedResult3.add("F324");
    expectedResult3.add("In-Flight");
    expectedResult3.add("0");

    ArrayList<String> expectedResult4 = new ArrayList<>();
    expectedResult4.add("F551");
    expectedResult4.add("In-Flight");
    expectedResult4.add("345");

    // Verifying if expected outcome occurred.
    assertEquals(4, statusTable.size());
    assertTrue(statusTable.contains(expectedResult1));
    assertTrue(statusTable.contains(expectedResult2));
    assertTrue(statusTable.contains(expectedResult3));
    assertTrue(statusTable.contains(expectedResult4));
  }

  // Test 11.
  // Testing removing multiple events will reflect correctly in status table.
  @Test
  void testRemoveMultipleEvents() {
    // Logging multiple events of multiple flights.
    testMultipleFlightEventsLarge();

    // Removing multiple events.
    testServiceLayer.removeEvent("F324 2021-03-29T12:00:00"); // F324 should no longer exist.
    testServiceLayer.removeEvent("F123 2021-03-29T10:00:00");
    testServiceLayer.removeEvent("F551 2021-03-29T12:00:00");

    // Getting status with timestamp after all events.
    statusTable = testServiceLayer.getStatus("2021-03-29T15:00:00");

    // Preparing expected data.
    ArrayList<String> expectedResult1 = new ArrayList<>();
    expectedResult1.add("F222");
    expectedResult1.add("Awaiting-Takeoff");
    expectedResult1.add("200");

    ArrayList<String> expectedResult2 = new ArrayList<>();
    expectedResult2.add("F123");
    expectedResult2.add("Landed");
    expectedResult2.add("-324");

    ArrayList<String> expectedResult3 = new ArrayList<>();
    expectedResult3.add("F551");
    expectedResult3.add("In-Flight");
    expectedResult3.add("345");

    // Verifying if expected outcome occurred.
    assertEquals(3, statusTable.size());
    assertTrue(statusTable.contains(expectedResult1));
    assertTrue(statusTable.contains(expectedResult2));
    assertTrue(statusTable.contains(expectedResult3));
  }

  // Test 12.
  // Testing that requesting previous status table from single set of flight events produces correct table.
  @Test
  void testSimplePastTable() {
    // Simple series of events for a single flight.
    testSingleFlightEvents();

    // Getting status with timestamp in between events.
    // Should correspond to f551event2 (which took place at 11), rather than f551event3 takes place at 12.
    statusTable = testServiceLayer.getStatus("2021-03-29T11:01:00");

    // Preparing expected data.
    ArrayList<String> expectedResult = new ArrayList<>();
    expectedResult.add("F551");
    expectedResult.add("In-Flight");
    expectedResult.add("345");

    // Verifying if expected outcome occurred.
    assertEquals(1, statusTable.size());
    assertTrue(statusTable.contains(expectedResult));
  }

  // Test 13.
  // Testing that corner-case timestamps produce correct tables.
  @Test
  void testSimplePastTableCornerCases() {
    // Simple series of events for a single flight.
    testSingleFlightEvents();

    // Corner Case: Before 11.

    // Preparing expected data.
    ArrayList<String> expectedResult = new ArrayList<>();
    expectedResult.add("F551");
    expectedResult.add("Awaiting-Takeoff");
    expectedResult.add("345");

    // Getting status with timestamp in between events.
    // Should correspond to f551event1 (which took place at 10).
    statusTable = testServiceLayer.getStatus("2021-03-29T10:59:59");

    // Verifying if expected outcome occurred.
    assertEquals(1, statusTable.size());
    assertTrue(statusTable.contains(expectedResult));

    // Corner Case: 11 onwards.

    // Changing expected data.
    expectedResult.clear();
    expectedResult.add("F551");
    expectedResult.add("In-Flight");
    expectedResult.add("345");

    // Getting status with timestamp in between events.
    // Should correspond to f551event2 as timestamps should be inclusive, and event took place at 11.
    statusTable = testServiceLayer.getStatus("2021-03-29T11:00:00");

    // Verifying if expected outcome occurred.
    assertEquals(1, statusTable.size());
    assertTrue(statusTable.contains(expectedResult));

    // Getting status with timestamp in between events.
    // Should correspond to f551event2 (which took place at 11), rather than f551event3 takes place at 12.
    statusTable = testServiceLayer.getStatus("2021-03-29T11:00:01");

    // Expected outcome should not change, verifying if occurred.
    assertEquals(1, statusTable.size());
    assertTrue(statusTable.contains(expectedResult));

    // Getting status with timestamp in between events.
    // Should correspond to f551event2 (which took place at 11), rather than f551event3 takes place at 12.
    statusTable = testServiceLayer.getStatus("2021-03-29T11:59:59");

    // Expected outcome should not change, verifying if occurred.
    assertEquals(1, statusTable.size());
    assertTrue(statusTable.contains(expectedResult));

    // Corner Cases: 12 onwards.

    // Changing expected data.
    expectedResult.clear();
    expectedResult.add("F551");
    expectedResult.add("Landed");
    expectedResult.add("225");

    // Getting status with timestamp in between events.
    // Should correspond to f551event3 (which took place at 12).
    statusTable = testServiceLayer.getStatus("2021-03-29T12:00:00");

    // Expected outcome should not change, verifying if occurred.
    assertEquals(1, statusTable.size());
    assertTrue(statusTable.contains(expectedResult));

    // Getting status with timestamp in between events.
    // Should correspond to f551event3 (which took place at 12).
    statusTable = testServiceLayer.getStatus("2021-03-29T12:00:01");

    // Expected outcome should not change, verifying if occurred.
    assertEquals(1, statusTable.size());
    assertTrue(statusTable.contains(expectedResult));
  }

  // Test 14.
  // Testing that requesting previous status tables produce correct tables for a complex event "database".
  @Test
  void testComplexPastTable() {
    // Multiple series of events for a multiple flights.
    testMultipleFlightEventsLarge();

    // Getting status with timestamp in between events.
    statusTable = testServiceLayer.getStatus("2021-03-29T11:30:00");

    // Preparing expected data for 11:30. Note that F324 should not exist at this time.
    ArrayList<String> expectedResult1 = new ArrayList<>();
    expectedResult1.add("F222");
    expectedResult1.add("Awaiting-Takeoff");
    expectedResult1.add("200");

    ArrayList<String> expectedResult2 = new ArrayList<>();
    expectedResult2.add("F123");
    expectedResult2.add("Awaiting-Takeoff");
    expectedResult2.add("428");

    ArrayList<String> expectedResult3 = new ArrayList<>();
    expectedResult3.add("F551");
    expectedResult3.add("In-Flight");
    expectedResult3.add("345");

    // Verifying if expected outcomes occurred.
    assertEquals(3, statusTable.size());
    assertTrue(statusTable.contains(expectedResult1));
    assertTrue(statusTable.contains(expectedResult2));
    assertTrue(statusTable.contains(expectedResult3));

    // Multiple series of events for a multiple flights.
    testMultipleFlightEventsLarge();

    // Getting new status with timestamp in between events.
    statusTable = testServiceLayer.getStatus("2021-03-29T13:00:00");

    // Preparing expected data for 13:00. Note that everything other than F123 and F222 should update.
    expectedResult1.clear();
    expectedResult1.add("F222");
    expectedResult1.add("Awaiting-Takeoff");
    expectedResult1.add("200");

    expectedResult2.clear();
    expectedResult2.add("F123");
    expectedResult2.add("In-Flight");
    expectedResult2.add("428");

    expectedResult3.clear();
    expectedResult3.add("F551");
    expectedResult3.add("Landed");
    expectedResult3.add("225");

    ArrayList<String> expectedResult4 = new ArrayList<>();
    expectedResult4.add("F324");
    expectedResult4.add("In-Flight");
    expectedResult4.add("0");

    // Verifying if expected outcomes occurred.
    assertEquals(4, statusTable.size());
    assertTrue(statusTable.contains(expectedResult1));
    assertTrue(statusTable.contains(expectedResult2));
    assertTrue(statusTable.contains(expectedResult3));
    assertTrue(statusTable.contains(expectedResult4));
  }

  // Test 15.
  // Testing that invalid event type returns false in Service Layer.
  @Test
  void testInvalidEventType() {
    // "Fuel" is not a valid input.
    invalidEvent = "F222 747 DUBLIN LONDON Fuel 2021-03-29T10:00:00 200";

    assertFalse(testServiceLayer.logEvent(invalidEvent));
  }

  // Test 16.
  // Testing that no event type returns false in Service Layer.
  @Test
  void testEmptyEventType() {
    // Event type column is blank.
    invalidEvent = "F222 747 DUBLIN LONDON  2021-03-29T10:00:00 200";

    assertFalse(testServiceLayer.logEvent(invalidEvent));
  }

  // Test 17.
  // Testing that one missing element returns false in Service Layer.
  @Test
  void testMissingPlaneID() {
    // Plane ID is missing.
    invalidEvent = "747 DUBLIN LONDON Re-Fuel 2021-03-29T10:00:00 200";

    assertFalse(testServiceLayer.logEvent(invalidEvent));
  }

  // Test 18.
  // Testing that empty origin returns false in Service Layer.
  @Test
  void testEmptyOrigin() {
    // Origin is empty.
    invalidEvent = "F222 747  London Re-Fuel 2021-03-29T10:00:00 200";

    assertFalse(testServiceLayer.logEvent(invalidEvent));
  }

  // Test 19.
  // Testing that empty destination returns false in Service Layer.
  @Test
  void testEmptyDestination() {
    // Destination is empty.
    invalidEvent = "F222 747 DUBLIN  Re-Fuel 2021-03-29T10:00:00 200";

    assertFalse(testServiceLayer.logEvent(invalidEvent));
  }

  // Test 20.
  // Testing that multiple missing details returns false in Service Layer.
  @Test
  void testMultipleMissingDetails() {
    // Multiple details missing.
    invalidEvent = "747 DUBLIN Re-Fuel 200";

    assertFalse(testServiceLayer.logEvent(invalidEvent));
  }

  // Test 21.
  // Testing that multiple empty details returns false.
  @Test
  void testMultipleEmptyDetails() {
    // Multiple details empty.
    invalidEvent = "F222  DUBLIN  Re-Fuel 2021-03-29T10:00:00 200";

    assertFalse(testServiceLayer.logEvent(invalidEvent));
  }

  // Test 22.
  // Testing that multiple extra details returns false in Service Layer.
  @Test
  void testMultipleExtraDetails() {
    // Multiple details added.
    invalidEvent = "F222 747 DUBLIN LONDON MOSCOW Re-fuel 2021-03-29T10:00:00 200 -30C";

    assertFalse(testServiceLayer.logEvent(invalidEvent));
  }

  // Test 23.
  // Testing that randoms log attempts throw an exception.
  @Test
  void testNonsensicalLog() {
    assertFalse(testServiceLayer.logEvent("blahblahblah"));

    assertFalse(testServiceLayer.logEvent("This is nonsense."));

    // Error despite being correct length.
    assertFalse(testServiceLayer.logEvent("Honestly speaking, this test is probably unnecessary."));
  }

  // Test 24.
  // Testing that calling remove method with invalid amount of details returns false.
  @Test
  void testRemoveInvalidAmount() {
    testMultipleFlightEventsLarge();

    // Too many arguments.
    assertFalse(testServiceLayer.removeEvent("F551 2021-03-29T12:00:00 200"));

    // Too few arguments.
    assertFalse(testServiceLayer.removeEvent("F551"));
  }

  // Test 25.
  // Testing that attempting to remove with invalid PlaneID returns false.
  @Test
  void testRemoveIncorrectPlaneID() {
    testMultipleFlightEventsLarge();

    assertFalse(testServiceLayer.removeEvent("F552 2021-03-29T12:00:00")); // Plane ID is incorrect.
  }

  // Test 26.
  // Testing that attempting to remove with invalid TimeStamp returns false.
  @Test
  void testRemoveIncorrectTimeStamp() {
    testMultipleFlightEventsLarge();

    assertFalse(testServiceLayer.removeEvent("F551 2020-03-29T12:00:00")); // Year is incorrect.
  }

  // Test 27.
  // Testing that attempting to remove with details that are not an ID / timestamp returns false.
  @Test
  void testRemoveInvalidDetails() {
    testMultipleFlightEventsLarge();

    assertFalse(testServiceLayer.removeEvent("F5541 2021-03-29T12:00:00")); // Invalid Plane ID.

    assertFalse(testServiceLayer.removeEvent("F551 20qwd0")); // Invalid timestamp.
  }

}